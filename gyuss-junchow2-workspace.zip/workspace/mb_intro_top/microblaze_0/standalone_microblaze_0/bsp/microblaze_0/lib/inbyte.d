../../../lib/inbyte.o: inbyte.c ../../../include/xparameters.h \
 ../../../include/xuartlite_l.h ../../../include/xil_types.h \
 ../../../include/xil_assert.h ../../../include/xil_io.h \
 ../../../include/xil_printf.h ../../../include/xparameters.h \
 ../../../include/bspconfig.h ../../../include/xstatus.h \
 ../../../include/mb_interface.h ../../../include/xil_exception.h
../../../include/xparameters.h:
../../../include/xuartlite_l.h:
../../../include/xil_types.h:
../../../include/xil_assert.h:
../../../include/xil_io.h:
../../../include/xil_printf.h:
../../../include/xparameters.h:
../../../include/bspconfig.h:
../../../include/xstatus.h:
../../../include/mb_interface.h:
../../../include/xil_exception.h:
